# 009-Box-Shadow
***

## Goal: Replicate both box-shadow examples.

*Instructions:*

Try to replicate the two example images provided on the webpage by adding styling in your
`app.css` file using the `box-shadow` property.

You can delete the borders on the provided boxes, they are there only to help you locate each box.

*Hint:* Read more about `box-shadow` here: [http://www.css3.info/preview/box-shadow/]. You can ignore the moz/webkit stuff.
